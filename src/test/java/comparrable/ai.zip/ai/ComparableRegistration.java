package comparrable.ai;

import java.io.IOException;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import resources.base;

public class ComparableRegistration extends base {
	public WebDriver driver;
	public static Logger log=LogManager.getLogger(base.class.getName());
	@BeforeTest
	public void setUp() throws IOException {
		driver=initializeDriver();
		log.info("driver initialized");
		
	}
	@Test
	public void comparrableRegistration() throws IOException, InterruptedException {
		String email="unsa14@gmail.com";
		String password="12345678";
		String firstName="Unsa";
		String lastName="Saleem";
		String organisation="Comparrable";
		String title="Test Title";
		String country="Pakistan";
		String phone="+923348283765";
		String primaralyWork="Asset";
		String others="testText";
		 String[] optionsNeededArray = { "Valuation", "Benchmarking", "M&A" , "Other..."};
		 int j=0;
		 String successMessage="Get premium access";
		 
		driver.get("https://testing.comparables.ai/login"); 
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));
		Thread.sleep(2000);
		driver.findElement(By.id("cookieaccept")).click();
		driver.findElement(By.xpath("//button[contains(text(),'Sign up!')]")).click();
		driver.findElement(By.xpath("//input[@placeholder='Your business email']")).sendKeys(email);
		driver.findElement(By.xpath("//button/span[contains(text(),'Register')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='password']")).sendKeys(password);
		driver.findElement(By.xpath("//*[@id='confirmPassword']")).sendKeys(password);
		driver.findElement(By.xpath("//*[@id='firstName']")).sendKeys(firstName);
		driver.findElement(By.xpath("//*[@id='lastName']")).sendKeys(lastName);
		driver.findElement(By.xpath("//*[@id='organization']")).sendKeys(organisation);
		driver.findElement(By.xpath("//*[@id='title']")).sendKeys(title);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[contains(text(),'Country*')]")).click();
		 Thread.sleep(2000);
         driver.findElement(By.xpath("//*[@id='react-select-2-input']")).sendKeys(country);
         driver.findElement(By.xpath("//*[@id='react-select-2-input']")).sendKeys(Keys.ENTER);
		
		driver.findElement(By.xpath("//*[@id='phone']")).sendKeys(phone);
		 JavascriptExecutor js = (JavascriptExecutor)driver;
	        js.executeScript("window.scrollBy(0,300)");
	        driver.findElement(By.xpath("//div[contains(text(),'Select one*')]")).click();
	         Thread.sleep(2000);
	         driver.findElement(By.xpath("//*[@id='react-select-3-input']")).sendKeys(primaralyWork);
	         driver.findElement(By.xpath("//*[@id='react-select-3-input']")).sendKeys(Keys.ENTER);
	         
	       //checkbox Options
	         WebElement e=driver.findElement(By.xpath("//div[contains(text(),'Select all that apply*')]"));
	         driver.findElement(By.xpath("//div[contains(text(),'Select all that apply*')]")).click();
			 Thread.sleep(1000);
//			 String p = driver.getPageSource();
//			 System.out.println(p);
			 List optionsNeededList = Arrays.asList(optionsNeededArray);
			 List<WebElement> Options = driver.findElements(By.xpath("//div[contains(@class, 'form-control__option')]"));
			 System.out.println(Options.size());
			 for(int i=0; i<Options.size();i++) {
				 String option = Options.get(i).getText();
				 System.out.println(option);
				 
				 if (optionsNeededList.contains(option))
					{
						j++;

						Options.get(i).click();
						if (j == optionsNeededArray.length)
						{
							break;
						}
					}
			 }
			 driver.findElement(By.xpath("//div[contains(text(),'Select all that apply*')]")).click();
			 driver.findElement(By.xpath("//*[@id=\"productHelpsWith\"]")).sendKeys(others);
//			Actions keyDown = new Actions(driver); 
//			keyDown.sendKeys(Keys.chord(Keys.DOWN, Keys.DOWN, Keys.ENTER)).perform();
//			keyDown.sendKeys(Keys.chord(Keys.DOWN, Keys.ENTER)).perform();

			 driver.findElement(By.xpath("//*[@id=\"Onboarding_Registration_Get_Access_Clicked_Success\"]/div[9]/button")).click();
			 Thread.sleep(3000);
			 
			 String actualMesssage=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[1]/div/div[1]/section/div/div/div/h2")).getText();
			 Assert.assertEquals(actualMesssage, successMessage);
		
		
	}

}